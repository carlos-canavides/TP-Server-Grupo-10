#!/bin/bash

#Función para mostrar ayuda
show_help() {
cat << EOF
NOMBRE
	backup_full.sh - Realiza una copia de seguridad de un directorio
SINOPSIS
	backup_full.sh [OPCIONES] <source_directory> <destination_directory>
DESCRIPCIÓN
	Este script realiza un backup del directorio origen al directorio destino.
	Esta copia de seguridad se guarda como un archivo comprimido .tar.gz
	con un nombre que incluye la fecha actual en formaro YYYYMMDD

	Si se proporcionan mas de 2 parametros, solo se usaran los primeros dos y
	se descartaran los demás. El script también verifica que ambos directorios
	existan antes de proceder con la copia
OPCIONES
	-h, --h
	Muestra esta ayuda
ARGUMENTOS
	source_directory
		Directorio de origen para realizar el backup
	destination_directory
		Directorio destino para almacenar el backup
EJEMPLOS
	./backup_full.sh /var/logs /backup_dir
EOF
}

#Verificamos si se pasó el parámetro -h para solicitar ayuda
if [ "$1" == "-h" ]; then
	show_help
	exit 0
fi

#Verificamos si se pasaron los argumentos requeridos para ejecutar el script
if [ $# -lt 2 ]; then
	echo "Error: Debes proporcionar los directorios de origen y destino"
	exit 1
fi

#Si se pasaron argumentos demás, osea más de 2, mostramos solo una advertencia y continuamos
if [ $# -gt 2 ]; then
	echo "Advertencia: Se proporcionaron más de 2 parámetros. Solo se usaran los primeros 2"
fi

#Asignamos los parametros necesario a las variables que utilizaremos
SOURCE="$1"
DEST="$2"

#Verificamos que los directorios existen
if [ ! -d "$SOURCE" ]; then
	echo "Error: El directorio de origen $SOURCE no existe"
	exit 1
fi

if [ ! -d "$DEST" ]; then
	echo "El directorio de destino $DEST no existe"
	exit 1
fi


#Procedemos a obtener la fecha actual en formato YYYYMMDD
DATE=$(date +%Y%m%d)

#Obtenemos el nombre del directorio de origen sin la ruta completa
SOURCE_NAME=$(basename "$SOURCE")

#Creamos el archivo de backup
BACKUP_FILE="$DEST/${SOURCE_NAME}_bkp_${DATE}.tar.gz"


#Ahora si estamos en condicione de realizar el backup
tar -czf "$BACKUP_FILE" -C "$SOURCE" .

#Verificamos que el backup se realizó correctamente
if [ $? -eq 0 ]; then
	echo "Backup de $SOURCE realizado con éxito en $BACKUP_FILE"
else
	echo "Error: Fallo el backup de $SOURCE"
	exit 1
fi

